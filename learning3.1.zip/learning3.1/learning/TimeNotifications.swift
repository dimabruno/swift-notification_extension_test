//
//  TimeNotifications.swift
//  learning
//
//  Created by Dmytro Pashkov on 25.01.2018.
//  Copyright © 2018 Dmytro Pashkov. All rights reserved.
//

import Foundation
import UserNotifications

class TimeNotifications{
    
    private var card = WordCard ()
    
    private var inSeconds = TimeInterval ()
    
    
    
    private lazy var correctAnswer = UNNotificationAction(identifier: "correctAnswer", title: card.correctAnswer, options: [])
    private lazy var nonCorrectAnswer1 = UNNotificationAction(identifier: "nonCorrectAnswer1", title: card.twoNonCorrectAnswers[0], options: [])
    private lazy var nonCorrectAnswer2 = UNNotificationAction(identifier: "nonCorrectAnswer2", title: card.twoNonCorrectAnswers[1], options: [])
    
    private lazy var categoryArray = [correctAnswer, nonCorrectAnswer1, nonCorrectAnswer2]
    
    private lazy var category = UNNotificationCategory(identifier: "myCategory", actions: categoryArray, intentIdentifiers: [], options: [])
    
   
    
    private lazy var triger = UNTimeIntervalNotificationTrigger(timeInterval: inSeconds, repeats: false)
    
    private let content = UNMutableNotificationContent()
    
    private lazy var request = UNNotificationRequest(identifier: "notification", content: content, trigger: triger)
    
    
    init(card : WordCard, timeInterval : TimeInterval) {
        self.card = card
        inSeconds = timeInterval
    }
    
    
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//// public funcs ////
    
    
    func sendNotification() {
        categoryArray.shuffle()
        
        UNUserNotificationCenter.current().setNotificationCategories([category])
        
        content.title = (card.title)
        content.categoryIdentifier = "myCategory"
        
        UNUserNotificationCenter.current().add(request)
        
    }
}




extension Notification.Name {
    static let notification = Notification.Name(rawValue: "notificationFromThirdViewController")
}
