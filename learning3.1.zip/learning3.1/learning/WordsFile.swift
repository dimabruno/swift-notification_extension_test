//
//  WordsFile.swift
//  learning
//
//  Created by Dmytro Pashkov on 11.01.2018.
//  Copyright © 2018 Dmytro Pashkov. All rights reserved.
//

import Foundation

final class Words {
    
    static var activeIndex = Int()
    
    static var listOfCt = [ct1, ct2, ct3] //массив всех категорий
    static var listOfAns = [ans1, ans2, ans3] //массив всех вопросов
    
    static let allCt = ["Фрукты и овощи", "Профессии", "Тест"]
    
    private static let ct1 = ["Aplle", "Orange", "Potatoe", "Banana", "Onion"] //Фрукты и овощи
    private static let ans1 = ["Яблоко", "Апельсин", "Картофель", "Банан", "Лук"]
    
    private static let ct2 = ["Farmer", "Fierman", "Doctor", "Manager", "Waiter", "Judge", "Policeman", "Postman"] //Профессии
    private static let ans2 = ["Фермер", "Пожарный", "Доктор", "Менеджер", "Официант", "Судья", "Полицейский", "Почтальон"]
    
    private static let ct3 = ["Test1", "Test2", "Test3", "Test4"] //Фрукты и овощи
    private static let ans3 = ["Тест1", "Тест2", "Тест3", "Тест4"]
}
