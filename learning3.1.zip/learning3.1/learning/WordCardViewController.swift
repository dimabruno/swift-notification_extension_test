//
//  ViewController.swift
//  learning
//
//  Created by Dmytro Pashkov on 10.01.2018.
//  Copyright © 2018 Dmytro Pashkov. All rights reserved.
//

import UIKit
import UserNotifications



/*
 Тут инициализируется cards (ее модель в файле WordCard). Ее нужно передать в файл NotificationViewController, там извлечь нужные данны и вывести их на вьюху. Отправлять данные нужно в момент, когда уведомление отправляется в очередь для отправки (func startNotifications)
 
 
 Файлы:
 
 WordCard - модель которая тут инициализируется
 CategoryChooserTableViewController - для работы с tabel view
 TimeNotifications - для отправки уведомлений
 
 WordsFile - не важно
 
 NotificationCardSinglton - когда все попытки передать данные не понълучились, пытался передать используя синглтон. В правильности реализации синглтона не уверен
 
 Если нужно будет связаться где то в более удобном месте, то вот телеграм @Kvadriceps
*/



class WordCardViewController: UIViewController, UNUserNotificationCenterDelegate {
    
    var cards = WordCard(categoryOfWords: Words.listOfCt[Words.activeIndex], answers: Words.listOfAns[Words.activeIndex]) /// Переменная которую нужно передать

    
    @IBOutlet weak var progressView: UIProgressView!
    
    @IBOutlet weak var resultLabel: UILabel!
    
    @IBOutlet weak var categoryTitle: UILabel!
    
    @IBOutlet weak var cardView: UIView! // top level view
   
    @IBOutlet weak var cardsTitle: UILabel!
    
    @IBOutlet var btOutlets: [UIButton]!
    
    var progressCounter : Float = 0 // progress bar counter
    
    @IBAction func answerButtons(_ sender: UIButton) // action with buttons
    {
        //animation block
        UIView.animate(withDuration: 0.4, animations: {
     
            self.progressCounter += Float(1) / Float(self.cards.getAmmountOfQuestions()) // increasing progress
     
            self.progressView.setProgress(self.progressCounter, animated: true) // animating progress view
            
            self.cardsTitle.layer.cornerRadius = 25
            
            for bt in self.btOutlets { // disallow interaction while animation is going
                bt.isUserInteractionEnabled = false
            }
            
            
            if sender.currentTitle! == self.cards.correctAnswer{ // if answer was correct
                self.cardsTitle.layer.backgroundColor = #colorLiteral(red: 0, green: 0.9768045545, blue: 0, alpha: 1)
                self.cards.ammountOfCorrectAnswers += 1 // counting correct answers
            }
            else{ // if answer was non correct
                self.cardsTitle.layer.backgroundColor = #colorLiteral(red: 1, green: 0.1491314173, blue: 0, alpha: 1)
            }
            
        }, completion : { (value : Bool) in
            
            if !self.cards.isEnoughWords{ // check if there enough words left, if no, then finish category

                for bt in self.btOutlets{
                    bt.isHidden = true
                }
                
                   // flipping card and showing results
                UIView.transition(with: self.cardView,
                                  duration: 0.6,
                                  options: [.transitionFlipFromLeft],
                                  
                                  animations: {self.resultLabel.text = "Вы набрали: \n\n \(self.cards.ammountOfCorrectAnswers) из \(self.cards.getAmmountOfQuestions()) \n\n правильных ответов";
                                    
                                    self.cardsTitle.layer.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 0)
                                    self.cardsTitle.text =  "Круг завершен"},
                                  
                                  completion: nil)
            }
                
            else {
                UIView.animate(withDuration: 0.4, animations: { self.cardsTitle.layer.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 0) },
                               completion : { (value : Bool) in
                                
                                for bt in self.btOutlets { // allow interaction after animation
                                    bt.isUserInteractionEnabled = true
                                }
                                
                                self.cardsTitle.layer.cornerRadius = 0

                                self.cards.setCard()
                                self.setCardsText()
                }
            )}
        })
    }
    
    
    
    
    @IBOutlet weak var notificationBtOutlet: UIButton!
    @IBAction func startNotifications(_ sender: UIButton) /// ОТПРАВКА УВЕДОМЛЕНИЯ
    {
        ///
        NotificationCard.shared.ammounOfQestions = cards.getAmmountOfQuestions()
        print (cards.getAmmountOfQuestions())
        ///
        
        
        let notification = TimeNotifications(card: cards, timeInterval: 5)
        notification.sendNotification()
        
    ///
         //NotificationCenter.default.post(name: .notification, object: cards)
    ///
    }

    
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                  didReceive response: UNNotificationResponse,
                                  withCompletionHandler completionHandler: @escaping () -> Void)
    {
            switch response.actionIdentifier {
            case UNNotificationDefaultActionIdentifier:
                 //the user swiped to unlock
                print("Default identifier")
            case "correctAnswer":
                self.cards.ammountOfCorrectAnswers += 1
                break
            case "nonCorrectAnswer1", "nonCorrectAnswer2":
                print ("It's NOT true")
            default:
                break
            }

        guard cards.isEnoughWords else {return}
        
        cards.setCard()
        setCardsText()

        ///
        // NotificationCenter.default.post(name: .notification, object: cards)
       ///
        
        let notification = TimeNotifications(card: cards, timeInterval: 5)
        notification.sendNotification()
        completionHandler()
    }
    
    
    private func setCardsText () { // outputing text to view
        cards.shuflCards()
        
        cardsTitle.text = cards.title
        
        for bt in btOutlets{ // set buttons text
            bt.setTitle(cards.btArray[btOutlets.index(of: bt)!], for: .normal)
        }
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        cardView.layer.cornerRadius = 25 // making view roundrect

        for bt in btOutlets{ // adding corner radius to buttons
            bt.layer.cornerRadius = 15
        }
        
        notificationBtOutlet.layer.cornerRadius = 25
        
        categoryTitle.text = Words.allCt[Words.activeIndex] 
        
        cards.setCard()
        setCardsText()
        
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { (success, error) in /*staf to write*/ }
        UNUserNotificationCenter.current().delegate = self
    }
    
}







@IBDesignable extension UIProgressView {
    
    @IBInspectable var barHeight : CGFloat {
        get {
            return transform.d * 2.0
        }
        set {
            // 2.0 Refers to the default height of 2
            let heightScale = newValue / 2.0
            let c = center
            transform = CGAffineTransform(scaleX: 1.0, y: heightScale)
            center = c
        }
    }
}

