//
//  NotificationCardSinglton.swift
//  learning
//
//  Created by Dmytro Pashkov on 27.01.2018.
//  Copyright © 2018 Dmytro Pashkov. All rights reserved.
//

import Foundation

final class NotificationCard{
    
    public static let shared = NotificationCard()
    
    private init () {print("I AM BOooooooRN")}
    
    public var ammountOfCorrectAnswers = Int()
    public var progressCounter = Float()
    public var ammounOfQestions = Int()
}
