//
//  WordCard.swift
//  learning
//
//  Created by Dmytro Pashkov on 10.01.2018.
//  Copyright © 2018 Dmytro Pashkov. All rights reserved.
//

import Foundation

class WordCard { //Class of card with a word
    
    private static var categoryWords = [String]() // variable with all eanglish words to learn
    private static var answers = [String]() // all translations to eanglish words
    
    private(set) var title = String() // randomly choosen eanglish word
    private(set) var correctAnswer = String() // translation of eanglish word
    private(set) var twoNonCorrectAnswers = [String]() // two non correct translation words, for buttons

    private var tempCategory: [String] = [] { //temporrary variable "counter" to anderstand, when category ends
        
        didSet{ // if there are no more words, set to 'true'
            if tempCategory.count == WordCard.categoryWords.count{
                isEnoughWords = false
            }
        }
    }
    
    
    lazy var btArray = [String]() // array of button names in random order, to shufle buttons
    
    var isEnoughWords = true
    
    var ammountOfCorrectAnswers = Int()
    
    init(categoryOfWords : [String], answers : [String]) {
        WordCard.categoryWords = categoryOfWords
        WordCard.answers = answers
    }
    
    init (){}


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//// public funcs ////
    
    
    func setCard () {
        selectTitle()
        selectTwoNonCorrectAnswers(correct: title)
        
        btArray.removeAll()
    }
    
    func shuflCards () {

        btArray.append(correctAnswer)
        btArray.append(twoNonCorrectAnswers[0])
        btArray.append(twoNonCorrectAnswers[1])
        
        btArray.shuffle() // extencion for shufling cards
    }
    
    func getAmmountOfQuestions () -> Int{
        return WordCard.categoryWords.count
    }
    
    
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//// private funcs ////

    
    private func selectTitle (){
       
        var randomIndex = Int()
        
        if tempCategory.count < WordCard.categoryWords.count{
        repeat{
        randomIndex = Int(arc4random_uniform(UInt32(WordCard.categoryWords.count)))
        }
        while tempCategory.contains(WordCard.categoryWords[randomIndex])
        }
        
            
            if !tempCategory.contains(WordCard.categoryWords[randomIndex]){
                title = WordCard.categoryWords[randomIndex] // set title
                correctAnswer = WordCard.answers[randomIndex]
                
                tempCategory.append(WordCard.categoryWords[randomIndex]) // adding to temp array, incrementing "counter"
            
                twoNonCorrectAnswers.removeAll() // if we are sellecting title, than we creating new card. So we need to reset non correct array of buttons
            }
    }
    
    private func selectTwoNonCorrectAnswers (correct title : String) {
        
        repeat {
            let randomIndex = Int(arc4random_uniform(UInt32(WordCard.answers.count)))
            
            if WordCard.answers[randomIndex] != correctAnswer && !twoNonCorrectAnswers.contains(WordCard.answers[randomIndex]){ // if it's not match with correct answer and we didn't select this word before
                twoNonCorrectAnswers.append(WordCard.answers[randomIndex])}
        }
        while twoNonCorrectAnswers.count < 2 // we need 2 non correct words, because there are only 3 buttons
    }
    
    
}



extension MutableCollection {
    /// Shuffles the contents of this collection.
    mutating func shuffle() {
        let c = count
        guard c > 1 else { return }
        
        for (firstUnshuffled, unshuffledCount) in zip(indices, stride(from: c, to: 1, by: -1)) {
            let d: IndexDistance = numericCast(arc4random_uniform(numericCast(unshuffledCount)))
            let i = index(firstUnshuffled, offsetBy: d)
            swapAt(firstUnshuffled, i)
        }
    }
}


