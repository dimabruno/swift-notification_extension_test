//
//  NotificationViewController.swift
//  notifications
//
//  Created by Dmytro Pashkov on 23.01.2018.
//  Copyright © 2018 Dmytro Pashkov. All rights reserved.
//

import UIKit
import UserNotifications
import UserNotificationsUI

class NotificationViewController: UIViewController, UNNotificationContentExtension {
    
    @IBOutlet var label: UILabel?
    @IBOutlet weak var progressView: UIProgressView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let size = view.bounds.size
        preferredContentSize = CGSize(width: size.width, height: size.height / 4.0)
    }

    func didReceive(_ notification: UNNotification) {
        self.label?.text = notification.request.content.title
        
        self.progressView.setProgress(NotificationCard.shared.progressCounter, animated: true)
    }

    
    func didReceive(_ response: UNNotificationResponse, completionHandler completion: @escaping (UNNotificationContentExtensionResponseOption) -> Void) {
        switch response.actionIdentifier{
        case "correctAnswer":
            label?.text = "Correct"
            NotificationCard.shared.ammountOfCorrectAnswers += 1
        case "nonCorrectAnswer1", "nonCorrectAnswer2":
            label?.text = "Non Correct"
        default:
            break
        }

        NotificationCard.shared.progressCounter += Float(1) / Float(NotificationCard.shared.ammounOfQestions)
        
        completion(.dismissAndForwardAction)
    }
}
 



